"""Receive fiber diameter measurements streamed over WiFi from an external PC.

This is the **WiFi (TCP) variant** of the diameter link. The fiber diameter is
measured on a separate computer (see the *FrED Fiber Measure with Streaming v3*
program) and streamed to the Raspberry Pi over a wireless TCP socket instead of
a USB cable.

The Pi is the **server**: it runs as a WiFi hotspot (see ``setup_hotspot.sh``)
and listens on a TCP port. The laptop joins the hotspot and connects to the Pi
as a client, then streams measurements. A background thread accepts the client
and reads the incoming messages, exposing the most recent diameter.

:meth:`ExternalDiameter.update` is a drop-in replacement for the old
``FiberCamera.camera_feedback`` call: it pushes the latest reading into the same
:class:`~database.Database` buffers and the diameter plot, so the rest of the
device code does not need to know where the number came from.

Wire protocol (newline-delimited JSON, UTF-8 — identical to the USB version)::

    {"v": 1, "d": 0.352, "u": "mm", "t": 12.345, "found": true}

    v      protocol version (int)
    d      diameter value, in the units given by ``u``
    u      unit string ("mm" or "px")
    t      sender elapsed seconds (informational)
    found  whether a fiber was detected in that frame

A keepalive line ``{"v": 1, "hb": true}`` may also be sent. Malformed lines are
ignored. The link is optional: if no laptop connects, the interface still runs,
simply reporting zero diameter until a stream arrives.

Jitter filter
-------------
The camera measurement jitters (fiber vibration + occasional single-frame
mis-detections: the real ``fred_experiment`` run showed typical steps of
~0.01 mm with outlier jumps up to 0.17 mm). Every received measurement with
``found=true`` is filtered on arrival: a median over the last 5 messages
removes short spikes (anything lasting less than ~3 of the ~20 messages/s),
then a 3-point average of the medians smooths the residual jitter. Total lag
is ~0.2-0.4 s at the normal streaming rate - small next to the process
dynamics. Undetected frames never enter the filter. ``get_latest()`` returns
the FILTERED value - graphs, recording and any control all see the clean
signal; ``get_latest_raw()`` returns the unfiltered measurement, which the
experiment export records alongside the filtered one.
"""
import json
import math
import socket
import statistics
import subprocess
import threading
import time
from collections import deque
from typing import TYPE_CHECKING, List, Tuple

from database import Database

if TYPE_CHECKING:
    from PyQt5.QtWidgets import QDoubleSpinBox
    from user_interface import UserInterface

# --------------------------------------------------------------------------- #
# Hotspot / network defaults. These MUST match what setup_hotspot.sh configures
# and what the laptop app (FrED Fiber Measure with Streaming v3) is pre-filled
# with, so the connection details shown on screen are correct.
# --------------------------------------------------------------------------- #
HOTSPOT_SSID = "FrED_Pi"
HOTSPOT_PASSWORD = "fredfiber123"
HOTSPOT_IP = "192.168.4.1"       # the Pi's address while acting as the hotspot
STREAM_PORT = 5005               # TCP port the laptop streams to


class ExternalDiameter:
    """Receive streamed fiber diameter over a WiFi TCP socket (Pi = server)."""

    PROTOCOL_VERSION = 1
    STREAM_TIMEOUT = 2.0       # seconds without data before "no signal"
    READ_TIMEOUT = 0.5         # recv poll period on the client socket
    SEND_TIMEOUT = 30.0        # deadline for one outgoing message (the
                               # recorded CSV is >1 MB in a single line and
                               # can NOT finish within READ_TIMEOUT on WiFi)

    # Jitter filter over received measurements (see module docstring):
    MEDIAN_WINDOW = 5          # median of the last N messages (despike)
    SMOOTH_WINDOW = 3          # average of the last N medians (smooth)

    def __init__(self, target_diameter: "QDoubleSpinBox", gui: "UserInterface",
                 host: str = "0.0.0.0", port: int = STREAM_PORT) -> None:
        self.target_diameter = target_diameter
        self.gui = gui
        self.host = host               # 0.0.0.0 -> listen on every interface
        self.port = port

        self.listening = False
        self.connected = False         # True while a laptop client is connected
        self.client_address = None     # (ip, port) of the connected laptop
        self.latest_diameter = 0.0     # FILTERED value (what everything uses)
        self.latest_raw = 0.0          # unfiltered, as received from the laptop
        self.latest_units = "mm"
        self.latest_found = False
        self.last_message_time = 0.0
        self.last_measurement_time = 0.0
        self.previous_time = 0.0
        self._median_buf = deque(maxlen=self.MEDIAN_WINDOW)
        self._smooth_buf = deque(maxlen=self.SMOOTH_WINDOW)

        self._server_sock = None
        self._client_sock = None
        self._lock = threading.Lock()
        self._send_lock = threading.Lock()   # serialise writes back to laptop
        self._stop = threading.Event()
        self._buffer = b""

        self._thread = threading.Thread(target=self._serve_loop, daemon=True)
        self._thread.start()

    # ------------------------------------------------------------------ #
    # Sending messages back to the laptop (status, recorded data)
    # ------------------------------------------------------------------ #
    def send_message(self, obj: dict) -> bool:
        """Send one newline-delimited JSON object to the connected laptop."""
        with self._send_lock:
            sock = self._client_sock
            if sock is None:
                return False
            try:
                payload = (json.dumps(obj) + "\n").encode("utf-8")
                # The socket normally carries the short READ_TIMEOUT (recv
                # polling). sendall() of a large payload (the recorded CSV)
                # cannot finish within it over WiFi, and a timed-out sendall
                # leaves a TRUNCATED line on the wire that corrupts every
                # message after it. Give sends their own generous deadline.
                sock.settimeout(self.SEND_TIMEOUT)
                try:
                    sock.sendall(payload)
                finally:
                    sock.settimeout(self.READ_TIMEOUT)
                return True
            except Exception as exc:
                # An unknown prefix of the message may already be on the wire,
                # so the stream is unrecoverable - close the connection so the
                # laptop sees a clean disconnect and can reconnect fresh,
                # instead of silently receiving garbage forever.
                print(f"[ExternalDiameter] Send failed ({exc}); closing the "
                      "client connection so the laptop can reconnect.")
                try:
                    sock.close()
                except Exception:
                    pass
                return False

    def _send_recorded_data(self) -> None:
        """Respond to a laptop 'get_data' request with the experiment CSV."""
        experiment = getattr(self.gui, "experiment", None)
        payload = experiment.data_payload() if experiment else None
        if payload is None:
            self.send_message({"type": "event", "event": "no_data",
                               "message": "No experiment data available yet."})
        else:
            self.send_message(payload)

    # ------------------------------------------------------------------ #
    # Network helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def local_ip_addresses() -> List[str]:
        """Return this Pi's non-loopback IPv4 addresses (hotspot IP first)."""
        ips: List[str] = []
        try:
            out = subprocess.check_output(["hostname", "-I"], text=True)
            ips = [tok for tok in out.split() if "." in tok]
        except Exception:
            pass
        if not ips:
            # Fallback: ask the OS which address it would use to reach the net.
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
                    probe.connect(("8.8.8.8", 80))
                    ips = [probe.getsockname()[0]]
            except Exception:
                ips = []
        # Show the hotspot address first if the Pi is running as the AP.
        ips.sort(key=lambda ip: (not ip.startswith("192.168.4."), ip))
        return ips

    def primary_ip(self) -> str:
        """Best guess at the address the laptop should connect to."""
        ips = self.local_ip_addresses()
        for ip in ips:
            if ip.startswith("192.168.4."):
                return ip
        return ips[0] if ips else HOTSPOT_IP

    # ------------------------------------------------------------------ #
    # Server / accept loop
    # ------------------------------------------------------------------ #
    def _open_server(self) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.settimeout(1.0)
            sock.bind((self.host, self.port))
            self.port = sock.getsockname()[1]
            sock.listen(1)
            self._server_sock = sock
            self.listening = True
            print(f"[ExternalDiameter] Listening on {self.host}:{self.port}")
            return True
        except Exception as exc:
            print(f"[ExternalDiameter] Could not open server socket: {exc}")
            self.listening = False
            return False

    def _serve_loop(self) -> None:
        # Keep trying to (re)open the listening socket until we succeed or stop.
        while not self._stop.is_set() and not self.listening:
            if not self._open_server():
                time.sleep(2.0)

        while not self._stop.is_set():
            try:
                client, addr = self._server_sock.accept()
            except socket.timeout:
                continue
            except Exception as exc:
                if self._stop.is_set():
                    break
                print(f"[ExternalDiameter] Accept error: {exc}")
                time.sleep(1.0)
                continue

            print(f"[ExternalDiameter] Laptop connected from {addr[0]}:{addr[1]}")
            client.settimeout(self.READ_TIMEOUT)
            with self._lock:
                self._client_sock = client
                self.connected = True
                self.client_address = addr
                self._buffer = b""
                self.last_measurement_time = 0.0
                self.latest_found = False
                self._median_buf.clear()
                self._smooth_buf.clear()
            self._read_client(client)
            # Client disconnected -> back to waiting for a new one.
            with self._lock:
                self.connected = False
                self.client_address = None
                self._client_sock = None
            try:
                client.close()
            except Exception:
                pass
            print("[ExternalDiameter] Laptop disconnected; waiting for a new "
                  "connection...")

    def _read_client(self, client: socket.socket) -> None:
        while not self._stop.is_set():
            try:
                data = client.recv(512)
            except socket.timeout:
                continue
            except Exception as exc:
                if self._stop.is_set():
                    return
                print(f"[ExternalDiameter] Read error: {exc}")
                return
            if not data:        # peer closed the connection
                return
            self._buffer += data
            while b"\n" in self._buffer:
                line, self._buffer = self._buffer.split(b"\n", 1)
                self._handle_line(line)

    def _handle_line(self, raw: bytes) -> None:
        try:
            text = raw.decode("utf-8", errors="ignore").strip()
            if not text:
                return
            message = json.loads(text)
        except (ValueError, json.JSONDecodeError):
            return  # ignore malformed lines / partial frames

        # Experiment commands from the laptop (v6).
        mtype = message.get("type")
        if mtype:
            self._handle_command(mtype, message)
            return

        if message.get("hb"):  # heartbeat / keepalive
            with self._lock:
                self.last_message_time = time.time()
            return
        if "d" not in message:
            return
        try:
            diameter = float(message.get("d", 0.0))
        except (TypeError, ValueError):
            return
        if not math.isfinite(diameter):
            with self._lock:
                self.latest_found = False
            return
        found = bool(message.get("found", True))
        with self._lock:
            units = message.get("u", "mm")
            if units != self.latest_units:
                self._median_buf.clear()
                self._smooth_buf.clear()
            # Advance the filter on every DETECTED measurement message
            # (~20/s). Undetected frames are kept out so a lost fiber cannot
            # drag the filtered value around.
            if found and diameter > 0:
                self._median_buf.append(diameter)
                self._smooth_buf.append(statistics.median(self._median_buf))
                self.latest_diameter = statistics.fmean(self._smooth_buf)
            self.latest_raw = diameter
            self.latest_units = units
            self.latest_found = found and diameter > 0
            self.last_message_time = time.time()
            self.last_measurement_time = self.last_message_time

    def _handle_command(self, mtype: str, message: dict) -> None:
        """Dispatch an experiment command received from the laptop."""
        experiment = getattr(self.gui, "experiment", None)
        if mtype == "experiment":
            if experiment is not None:
                try:
                    if getattr(self.gui, "agent_stop_latched", False):
                        raise ValueError("Agent safety stop is latched. Resolve the cause and restart FrED.")
                    experiment.start(message.get("params", {}))
                except ValueError as exc:
                    self.send_message({"type": "event", "event": "experiment_rejected",
                                       "message": str(exc)})
        elif mtype == "abort":
            if experiment is not None:
                experiment.abort()
        elif mtype == "get_data":
            self._send_recorded_data()
        # unknown types are ignored

    # ------------------------------------------------------------------ #
    # Public access
    # ------------------------------------------------------------------ #
    def measurement_snapshot(self) -> dict:
        """One coherent snapshot, including validity for research exports."""
        with self._lock:
            age = time.time() - self.last_measurement_time if self.last_measurement_time else None
            streaming = bool(self.connected and age is not None and age < self.STREAM_TIMEOUT)
            valid = bool(streaming and self.latest_found and self.latest_units == "mm"
                         and math.isfinite(self.latest_diameter) and self.latest_diameter > 0)
            return {"diameter": self.latest_diameter, "raw": self.latest_raw,
                    "found": self.latest_found, "units": self.latest_units,
                    "age": age, "streaming": streaming, "valid": valid}

    def get_latest(self) -> Tuple[float, bool, float]:
        """Return (FILTERED diameter, found, seconds_since_last_message)."""
        with self._lock:
            age = time.time() - self.last_measurement_time if self.last_measurement_time else float("inf")
            return self.latest_diameter, self.latest_found, age

    def get_latest_raw(self) -> float:
        """Return the last diameter exactly as received (no jitter filter)."""
        with self._lock:
            return self.latest_raw

    def is_streaming(self) -> bool:
        """True if a laptop is connected and a message arrived recently."""
        with self._lock:
            if not self.connected or not self.last_message_time:
                return False
            return (time.time() - self.last_message_time) < self.STREAM_TIMEOUT

    def connection_info(self) -> dict:
        """Everything the GUI needs to show the user how to connect."""
        with self._lock:
            client = (f"{self.client_address[0]}:{self.client_address[1]}"
                      if self.client_address else None)
        return {
            "ssid": HOTSPOT_SSID,
            "password": HOTSPOT_PASSWORD,
            "ip": self.primary_ip(),
            "all_ips": self.local_ip_addresses(),
            "port": self.port,
            "listening": self.listening,
            "client": client,
        }

    def status_text(self) -> str:
        """Human-readable status string for the GUI."""
        if not self.listening:
            return f"Diameter link: starting WiFi server on port {self.port}..."
        if not self.connected:
            return (f"Diameter link: waiting for laptop on "
                    f"{self.primary_ip()}:{self.port}")
        if self.is_streaming():
            diameter, found, _ = self.get_latest()
            if found:
                return f"Diameter link: streaming - {diameter:.4f} mm"
            return "Diameter link: streaming - no fiber detected"
        return "Diameter link: laptop connected, waiting for data..."

    # ------------------------------------------------------------------ #
    # Hardware-loop hook (replaces FiberCamera.camera_feedback)
    # ------------------------------------------------------------------ #
    def update(self, current_time: float) -> None:
        """Feed the latest streamed diameter into the plot and the database."""
        try:
            diameter, _found, _age = self.get_latest()
            target = self.gui.get_target_diameter()

            self.gui.diameter_plot.update_plot(current_time, diameter, target)

            Database.camera_timestamps.append(current_time)
            Database.diameter_readings.append(diameter)
            Database.diameter_setpoint.append(target)
            Database.diameter_delta_time.append(current_time - self.previous_time)
            self.previous_time = current_time
        except Exception as exc:
            print(f"Error in external diameter update: {exc}")

    def close(self) -> None:
        """Stop the server thread and release the sockets."""
        self._stop.set()
        for sock in (self._client_sock, self._server_sock):
            if sock is not None:
                try:
                    sock.close()
                except Exception:
                    pass
        self._client_sock = None
        self._server_sock = None
        self.listening = False
        self.connected = False
