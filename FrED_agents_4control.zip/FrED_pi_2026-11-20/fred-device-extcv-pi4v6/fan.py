"""File for the fan controller"""
import RPi.GPIO as GPIO
from user_interface import UserInterface
from database import Database

class Fan:
    """Controller for the fan"""
    PIN = 13
    def __init__(self, gui: UserInterface) -> None:
        self.gui = gui
        self.duty_cycle = 0.0
        self.pwm = None
        GPIO.setup(Fan.PIN, GPIO.OUT)
        print(self.gui.device_started)

    def start(self, frequency: float, duty_cycle: float) -> None:
        """Start the fan PWM"""
        self.pwm = GPIO.PWM(Fan.PIN, frequency)
        self.pwm.start(duty_cycle)

    def stop(self) -> None:
        """Stop the fan PWM"""
        if self.pwm:
            self.pwm.stop()

    def update_duty_cycle(self, duty_cycle: float) -> None:
        """Update speed"""
        self.pwm.ChangeDutyCycle(duty_cycle)
        Database.fan_duty_cycle.append(duty_cycle)

    def control_loop(self) -> None:
        """Set the desired speed (or hold at 0 when the fan is stopped)."""
        try:
            if getattr(self.gui, "fan_enabled", True):
                self.update_duty_cycle(self.gui.get_fan_duty())
            else:
                self.update_duty_cycle(0)
        except Exception as e:
            print(f"Error in fan control loop: {e}")
            self.gui.show_message("Error in fan control loop",
                                    "Please restart the program.")
